# Chess Game for MIA Task 4.2

## Make sure the images are in the same directort as the python file for it to work
this was so tiring....had to rely so much on the AI 
